package net.irisshaders.iris.pipeline.transform;

import org.apache.commons.io.FilenameUtils;
import org.embeddedt.embeddium.impl.gl.shader.ShaderType;
import org.taumc.celeritas.api.v0.CeleritasShadersApi;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static net.irisshaders.iris.IrisLogging.IRIS_LOGGER;
import static org.embeddedt.embeddium.compat.mc.PlatformUtilService.PLATFORM_UTIL;

/**
 * Static class that deals with printing the patched_shader folder.
 */
public class ShaderPrinter {
	private static final Path debugOutDir = PLATFORM_UTIL.getGameDir().resolve("patched_shaders");
	private static boolean outputLocationCleared = false;
	private static int programCounter = 0;

	public static void resetPrintState() {
		outputLocationCleared = false;
		programCounter = 0;
	}

	public static void deleteIfClearing() {
		if (!outputLocationCleared) {
			try {
				if (Files.exists(debugOutDir)) {
					try (Stream<Path> stream = Files.list(debugOutDir)) {
						stream.forEach(path -> {
							try {
								Files.delete(path);
							} catch (IOException e) {
								throw new RuntimeException(e);
							}
						});
					}
				}

				Files.createDirectories(debugOutDir);
			} catch (IOException e) {
				IRIS_LOGGER.warn("Failed to initialize debug patched shader source location", e);
			}
			outputLocationCleared = true;
		}
	}

	public static ProgramPrintBuilder printProgram(String name) {
		return new ProgramPrintBuilder(name);
	}

	public static class ProgramPrintBuilder {
		// copy the debug flag if for some reason the debug flag changes during the
		// lifetime of this builder object
		private final boolean isActive = CeleritasShadersApi.getInstance().areDebugOptionsEnabled();

		// the prefix is created at instantiation time so that all sources attached to
		// this builder use the same counter prefix
		private final String prefix = isActive ? String.format("%03d_", ++programCounter) : null;

		// the prefix and the sources list aren't created if debug is disabled
		private final List<String> sources = isActive ? new ArrayList<>(ShaderType.values().length * 2) : null;

		private String name;
		private boolean done = false; // makes the print function idempotent

		public ProgramPrintBuilder(String name) {
			setName(name);
		}

		public ProgramPrintBuilder setName(String name) {
			this.name = name;
			return this;
		}

		private void addItem(String extension, String content) {
			if (content != null && sources != null) {
				sources.add(prefix + name + extension);
				sources.add(content);
			}
		}

		public ProgramPrintBuilder addSource(ShaderType type, String source) {
			if (sources == null) {
				return this;
			}
			addItem("." + type.fileExtension, source);
			return this;
		}

		public ProgramPrintBuilder addSources(Map<ShaderType, String> sources) {
			if (sources == null) {
				return this;
			}
			for (Map.Entry<ShaderType, String> entry : sources.entrySet()) {
				addSource(entry.getKey(), entry.getValue());
			}
			return this;
		}

		public ProgramPrintBuilder addJson(String json) {
			if (sources == null) {
				return this;
			}
			addItem(".json", json);
			return this;
		}

		public void print() {
			if (done) {
				return;
			}
			done = true;
			if (isActive) {
				if (!outputLocationCleared) {
					try {
						if (Files.exists(debugOutDir)) {
							try (Stream<Path> stream = Files.list(debugOutDir).filter(s -> {
								return !FilenameUtils.getExtension(s.toString()).contains("properties");
							})) {
								stream.forEach(path -> {
									try {
										Files.delete(path);
									} catch (IOException e) {
										throw new RuntimeException(e);
									}
								});
							}
						}

						Files.createDirectories(debugOutDir);
					} catch (IOException e) {
						IRIS_LOGGER.warn("Failed to initialize debug patched shader source location", e);
					}
					outputLocationCleared = true;
				}

				try {
					for (int i = 0; i < sources.size(); i += 2) {
						Files.writeString(debugOutDir.resolve(sources.get(i)), sources.get(i + 1));
					}
				} catch (IOException e) {
					IRIS_LOGGER.warn("Failed to write debug patched shader source", e);
				}
			}
		}
	}
}
